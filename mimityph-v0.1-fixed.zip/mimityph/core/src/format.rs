//! Русский формат счётчиков: 856, 1,8 тыс., 12,4 тыс., 1,2 млн.

/// `tenths` — число в десятых долях единицы (целочисленно, без погрешности float).
fn one_decimal(tenths: u64, suffix: &str) -> String {
    let (int, frac) = (tenths / 10, tenths % 10);
    if frac == 0 { format!("{int} {suffix}") } else { format!("{int},{frac} {suffix}") }
}

/// Дробная часть отбрасывается, а не округляется: 999 950 не станет «1000 тыс.».
pub fn count_ru(n: u64) -> String {
    match n {
        0..=999 => n.to_string(),
        1_000..=999_999 => one_decimal(n / 100, "тыс."),
        _ => one_decimal(n / 100_000, "млн"),
    }
}

/// 83.4 -> "1:23"
pub fn duration_mmss(seconds: f64) -> String {
    let s = seconds.max(0.0) as u64;
    format!("{}:{:02}", s / 60, s % 60)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn counts() {
        assert_eq!(count_ru(0), "0");
        assert_eq!(count_ru(856), "856");
        assert_eq!(count_ru(1_000), "1 тыс.");
        assert_eq!(count_ru(1_800), "1,8 тыс.");
        assert_eq!(count_ru(12_400), "12,4 тыс.");
        assert_eq!(count_ru(999_999), "999,9 тыс.");
        assert_eq!(count_ru(1_200_000), "1,2 млн");
    }

    #[test]
    fn duration() {
        assert_eq!(duration_mmss(83.4), "1:23");
        assert_eq!(duration_mmss(-5.0), "0:00");
    }
}

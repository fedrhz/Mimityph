use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct Video {
    pub id: i64,
    pub kind: String, // "file" | "tiktok"
    pub author: String,
    pub caption: String,
    pub video_url: Option<String>,
    pub thumb_url: Option<String>,
    pub tiktok_url: Option<String>,
    pub tiktok_html: Option<String>,
    pub duration: Option<f64>,
    pub likes: u64,
    pub comments: u64,
    pub liked: bool,
    pub created_at: f64,
}

#[derive(Debug, Clone, Deserialize)]
pub struct FeedPage {
    pub items: Vec<Video>,
    pub next_before: Option<i64>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Session {
    pub user_id: i64,
    pub name: String,
    pub token: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Comment {
    pub id: i64,
    pub author: String,
    pub text: String,
    pub created_at: f64,
}

#[derive(Debug, Clone, Deserialize)]
pub struct LikeResult {
    pub liked: bool,
    pub likes: u64,
}

/// События WebSocket (поле `type` задаёт вариант).
#[derive(Debug, Clone, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum ServerEvent {
    NewVideo { video_id: i64 },
    VideoStatus { video_id: i64, status: String },
    Like { video_id: i64, liked: bool, likes: u64 },
    Comment { video_id: i64, comment_id: i64 },
    Sync { data: serde_json::Value },
}

use crate::types::*;
use reqwest::{multipart, Client};
use std::path::Path;

#[derive(Debug, thiserror::Error)]
pub enum ApiError {
    #[error("сеть: {0}")]
    Network(#[from] reqwest::Error),
    #[error("файл: {0}")]
    Io(#[from] std::io::Error),
    #[error("сервер ответил {status}: {detail}")]
    Server { status: u16, detail: String },
}

#[derive(Clone)]
pub struct Api {
    base: String,
    token: Option<String>,
    http: Client,
}

impl Api {
    pub fn new(base: impl Into<String>) -> Self {
        Self { base: base.into().trim_end_matches('/').to_string(), token: None, http: Client::new() }
    }

    pub fn with_token(mut self, token: String) -> Self {
        self.token = Some(token);
        self
    }

    pub fn abs_url(&self, path: &str) -> String {
        if path.starts_with("http") { path.into() } else { format!("{}{}", self.base, path) }
    }

    pub fn ws_url(&self) -> String {
        let ws = self.base.replacen("http", "ws", 1);
        format!("{ws}/ws?token={}", self.token.clone().unwrap_or_default())
    }

    fn auth(&self, rb: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
        match &self.token { Some(t) => rb.bearer_auth(t), None => rb }
    }

    async fn check(resp: reqwest::Response) -> Result<reqwest::Response, ApiError> {
        if resp.status().is_success() { return Ok(resp); }
        let status = resp.status().as_u16();
        let detail = resp.json::<serde_json::Value>().await.ok()
            .and_then(|v| v["detail"].as_str().map(String::from)).unwrap_or_default();
        Err(ApiError::Server { status, detail })
    }

    pub async fn login(&self, name: &str, device: &str) -> Result<Session, ApiError> {
        let r = self.http.post(format!("{}/api/auth/guest", self.base))
            .json(&serde_json::json!({ "name": name, "device": device })).send().await?;
        Ok(Self::check(r).await?.json().await?)
    }

    pub async fn feed(&self, before: Option<i64>) -> Result<FeedPage, ApiError> {
        let mut rb = self.http.get(format!("{}/api/feed", self.base)).query(&[("limit", "10")]);
        if let Some(b) = before { rb = rb.query(&[("before", b.to_string())]); }
        Ok(Self::check(self.auth(rb).send().await?).await?.json().await?)
    }

    pub async fn like(&self, id: i64) -> Result<LikeResult, ApiError> {
        let rb = self.http.post(format!("{}/api/videos/{id}/like", self.base));
        Ok(Self::check(self.auth(rb).send().await?).await?.json().await?)
    }

    pub async fn comments(&self, id: i64) -> Result<Vec<Comment>, ApiError> {
        let rb = self.http.get(format!("{}/api/videos/{id}/comments", self.base));
        Ok(Self::check(self.auth(rb).send().await?).await?.json().await?)
    }

    pub async fn add_comment(&self, id: i64, text: &str) -> Result<(), ApiError> {
        let rb = self.http.post(format!("{}/api/videos/{id}/comments", self.base))
            .json(&serde_json::json!({ "text": text }));
        Self::check(self.auth(rb).send().await?).await?;
        Ok(())
    }

    pub async fn add_tiktok(&self, url: &str, caption: &str) -> Result<(), ApiError> {
        let rb = self.http.post(format!("{}/api/videos/tiktok", self.base))
            .json(&serde_json::json!({ "url": url, "caption": caption }));
        Self::check(self.auth(rb).send().await?).await?;
        Ok(())
    }

    pub async fn upload(&self, path: &Path, caption: &str) -> Result<(), ApiError> {
        let bytes = std::fs::read(path)?;
        let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("video.mp4").to_string();
        self.upload_bytes(name, bytes, caption).await
    }

    /// Целиком в памяти. Для больших видео нужна потоковая отправка (см. план).
    pub async fn upload_bytes(&self, name: String, bytes: Vec<u8>, caption: &str) -> Result<(), ApiError> {
        let form = multipart::Form::new()
            .text("caption", caption.to_string())
            .part("file", multipart::Part::bytes(bytes).file_name(name));
        let rb = self.http.post(format!("{}/api/videos", self.base)).multipart(form);
        Self::check(self.auth(rb).send().await?).await?;
        Ok(())
    }
}

impl PartialEq for Api {
    fn eq(&self, other: &Self) -> bool {
        self.base == other.base && self.token == other.token
    }
}

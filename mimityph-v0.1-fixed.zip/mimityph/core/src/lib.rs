//! Общие типы, API-клиент и форматирование для клиентов Mimi Typh.
pub mod api;
pub mod format;
pub mod types;

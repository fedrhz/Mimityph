# Mimi Typh

Видеоприложение: лента, загрузка видео, сервер, синхронизация устройств, TikTok через oEmbed.

- `server/` — Python 3.11+, FastAPI, SQLite, ffmpeg
- `core/`   — Rust: типы, API-клиент, форматирование чисел (ru)
- `app/`    — Rust: Dioxus 0.6 (Android + Windows)
- `design/` — спецификация и макет

## Сервер
    cd server
    python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
    pip install -r requirements.txt
    uvicorn app.main:app --host 0.0.0.0 --port 8000
Нужен ffmpeg в PATH. Документация API: http://localhost:8000/docs

Тесты: `pip install pytest && pytest -q`

## Клиент
    cargo install dioxus-cli
    cargo test -p mimityph-core
    MIMITYPH_SERVER=http://192.168.0.10:8000 dx serve --platform desktop -p mimityph-app
    # Android: dx serve --platform android   (Android SDK + NDK, JAVA_HOME)
    # Windows EXE: dx bundle --platform desktop --release -p mimityph-app

## Что НЕ проверено
Rust-код написан без компиляции (в среде не было cargo): первый `cargo check`
может потребовать мелких правок под вашу версию Dioxus. Сервер FastAPI тоже не
запускался (не было пакетов): проверены синтаксис, слой БД и ffmpeg-команды.

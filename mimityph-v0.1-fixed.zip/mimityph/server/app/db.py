"""SQLite-слой. Одно соединение на запрос, WAL, без ORM — меньше зависимостей."""
import secrets
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path("data/mimityph.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS tokens(
  token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  device TEXT NOT NULL, created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS videos(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  kind TEXT NOT NULL CHECK(kind IN ('file','tiktok')),
  status TEXT NOT NULL DEFAULT 'ready' CHECK(status IN ('processing','ready','failed')),
  caption TEXT NOT NULL DEFAULT '', video_path TEXT, thumb_path TEXT,
  tiktok_url TEXT, tiktok_html TEXT, duration REAL, created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS likes(
  user_id INTEGER NOT NULL, video_id INTEGER NOT NULL, PRIMARY KEY(user_id, video_id));
CREATE TABLE IF NOT EXISTS comments(
  id INTEGER PRIMARY KEY, video_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
  text TEXT NOT NULL, created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS idx_videos_created ON videos(id DESC);
"""


def init(path: Path | None = None) -> None:
    global DB_PATH
    if path is not None:
        DB_PATH = path
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with connect() as c:
        c.executescript(SCHEMA)


@contextmanager
def connect():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    try:
        yield c
        c.commit()
    finally:
        c.close()


def login_guest(name: str, device: str) -> tuple[int, str]:
    """Имя = аккаунт. Каждое устройство получает свой токен; все токены одного имени
    видят общие события (синхронизация между устройствами)."""
    with connect() as c:
        row = c.execute("SELECT id FROM users WHERE name=?", (name,)).fetchone()
        uid = row["id"] if row else c.execute(
            "INSERT INTO users(name, created_at) VALUES(?,?)", (name, time.time())).lastrowid
        token = secrets.token_urlsafe(32)
        c.execute("INSERT INTO tokens VALUES(?,?,?,?)", (token, uid, device, time.time()))
    return uid, token


def user_by_token(token: str):
    with connect() as c:
        return c.execute(
            "SELECT u.id, u.name FROM tokens t JOIN users u ON u.id=t.user_id WHERE t.token=?",
            (token,)).fetchone()


def add_video(user_id: int, kind: str, caption: str, **f) -> int:
    status = "processing" if kind == "file" else "ready"
    with connect() as c:
        return c.execute(
            "INSERT INTO videos(user_id,kind,status,caption,video_path,thumb_path,tiktok_url,"
            "tiktok_html,duration,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (user_id, kind, status, caption, f.get("video_path"), f.get("thumb_path"),
             f.get("tiktok_url"), f.get("tiktok_html"), f.get("duration"), time.time())).lastrowid


def finish_video(video_id: int, ok: bool, video_path=None, thumb_path=None, duration=None) -> None:
    with connect() as c:
        c.execute("UPDATE videos SET status=?, video_path=COALESCE(?,video_path), "
                  "thumb_path=?, duration=? WHERE id=?",
                  ("ready" if ok else "failed", video_path, thumb_path, duration, video_id))


_FEED_SQL = """
SELECT v.*, u.name AS author,
  (SELECT COUNT(*) FROM likes l WHERE l.video_id=v.id) AS likes,
  (SELECT COUNT(*) FROM comments m WHERE m.video_id=v.id) AS comments,
  EXISTS(SELECT 1 FROM likes l WHERE l.video_id=v.id AND l.user_id=?) AS liked
FROM videos v JOIN users u ON u.id=v.user_id
"""


def feed(viewer_id: int, before_id: int | None, limit: int):
    with connect() as c:
        if before_id:
            return c.execute(_FEED_SQL + " WHERE v.status='ready' AND v.id<? ORDER BY v.id DESC LIMIT ?",
                             (viewer_id, before_id, limit)).fetchall()
        return c.execute(_FEED_SQL + " WHERE v.status='ready' ORDER BY v.id DESC LIMIT ?",
                         (viewer_id, limit)).fetchall()


def get_video(viewer_id: int, video_id: int):
    with connect() as c:
        return c.execute(_FEED_SQL + " WHERE v.id=?", (viewer_id, video_id)).fetchone()


def toggle_like(user_id: int, video_id: int) -> bool:
    with connect() as c:
        if c.execute("DELETE FROM likes WHERE user_id=? AND video_id=?", (user_id, video_id)).rowcount:
            return False
        c.execute("INSERT INTO likes VALUES(?,?)", (user_id, video_id))
        return True


def add_comment(user_id: int, video_id: int, text: str) -> int:
    with connect() as c:
        return c.execute("INSERT INTO comments(video_id,user_id,text,created_at) VALUES(?,?,?,?)",
                         (video_id, user_id, text, time.time())).lastrowid


def list_comments(video_id: int, limit: int = 100):
    with connect() as c:
        return c.execute(
            "SELECT m.id, u.name AS author, m.text, m.created_at FROM comments m "
            "JOIN users u ON u.id=m.user_id WHERE m.video_id=? ORDER BY m.id DESC LIMIT ?",
            (video_id, limit)).fetchall()

"""Рассылка событий по WebSocket: всем устройствам одного аккаунта (sync) или всем (лента)."""
from collections import defaultdict

from fastapi import WebSocket


class Hub:
    def __init__(self) -> None:
        self._by_user: dict[int, set[WebSocket]] = defaultdict(set)

    def add(self, user_id: int, ws: WebSocket) -> None:
        self._by_user[user_id].add(ws)

    def remove(self, user_id: int, ws: WebSocket) -> None:
        self._by_user[user_id].discard(ws)

    async def _send(self, sockets, event: dict) -> None:
        for ws in list(sockets):
            try:
                await ws.send_json(event)
            except Exception:
                for s in self._by_user.values():
                    s.discard(ws)

    async def to_user(self, user_id: int, event: dict) -> None:
        await self._send(self._by_user[user_id], event)

    async def to_all(self, event: dict) -> None:
        await self._send([w for s in self._by_user.values() for w in s], event)

"""Обработка загрузок через ffmpeg: H.264/AAC mp4 (faststart) + превью."""
import json
import subprocess
from pathlib import Path

MAX_SECONDS = 180


def probe_duration(src: Path) -> float:
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", str(src)],
        capture_output=True, text=True, timeout=30, check=True).stdout
    return float(json.loads(out)["format"]["duration"])


def transcode_cmd(src: Path, dst: Path) -> list[str]:
    # Вертикальное 9:16 до 720x1280: масштаб с сохранением пропорций + чёрные поля.
    vf = ("scale=720:1280:force_original_aspect_ratio=decrease,"
          "pad=720:1280:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1")
    return ["ffmpeg", "-y", "-i", str(src), "-t", str(MAX_SECONDS), "-vf", vf,
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(dst)]


def thumb_cmd(src: Path, dst: Path, at: float) -> list[str]:
    return ["ffmpeg", "-y", "-ss", f"{at:.2f}", "-i", str(src), "-frames:v", "1",
            "-vf", "scale=360:-2", str(dst)]


def process(src: Path, out_dir: Path, stem: str) -> tuple[Path, Path, float]:
    """Блокирующая функция — вызывать из фонового потока. Бросает исключение при ошибке."""
    out_dir.mkdir(parents=True, exist_ok=True)
    duration = min(probe_duration(src), MAX_SECONDS)
    video, thumb = out_dir / f"{stem}.mp4", out_dir / f"{stem}.jpg"
    subprocess.run(transcode_cmd(src, video), capture_output=True, timeout=900, check=True)
    subprocess.run(thumb_cmd(video, thumb, min(1.0, duration / 2)),
                   capture_output=True, timeout=60, check=True)
    return video, thumb, duration

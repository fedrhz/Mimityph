"""TikTok только разрешённым способом: официальный oEmbed. Видео не скачивается и
не перезаливается — клиент показывает встроенный плеер TikTok."""
import re
from urllib.parse import urlparse

import httpx

ALLOWED_HOSTS = {"tiktok.com", "www.tiktok.com", "vm.tiktok.com", "vt.tiktok.com", "m.tiktok.com"}
OEMBED = "https://www.tiktok.com/oembed"


class BadTikTokUrl(ValueError):
    pass


def validate(url: str) -> str:
    p = urlparse(url.strip())
    if p.scheme != "https" or (p.hostname or "").lower() not in ALLOWED_HOSTS:
        raise BadTikTokUrl("Нужна ссылка вида https://www.tiktok.com/@user/video/…")
    return p.geturl()


# TikTok-разметка содержит <script src="https://www.tiktok.com/embed.js">; остальное режем.
_SCRIPT_OK = re.compile(r'<script[^>]+src="https://www\.tiktok\.com/embed\.js"[^>]*></script>', re.I)


def sanitize_html(html: str) -> str:
    html = _SCRIPT_OK.sub("", html)           # скрипт клиент подключает сам
    if "<script" in html.lower():
        raise BadTikTokUrl("Неожиданная разметка в ответе oEmbed")
    return html


async def fetch(url: str) -> dict:
    url = validate(url)
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(OEMBED, params={"url": url})
    if r.status_code != 200:
        raise BadTikTokUrl("TikTok не вернул данные для этой ссылки")
    data = r.json()
    return {"url": url, "html": sanitize_html(data.get("html", "")),
            "title": data.get("title", ""), "author": data.get("author_name", ""),
            "thumbnail": data.get("thumbnail_url")}

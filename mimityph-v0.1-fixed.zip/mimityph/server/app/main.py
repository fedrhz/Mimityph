import asyncio
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import (BackgroundTasks, Depends, FastAPI, File, Form, Header, HTTPException,
                     UploadFile, WebSocket, WebSocketDisconnect)
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import db, media, tiktok
from .hub import Hub

DATA = Path("data")
UPLOADS, MEDIA = DATA / "uploads", DATA / "media"
MAX_UPLOAD = 300 * 1024 * 1024
ALLOWED_EXT = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v", ".3gp"}
hub = Hub()


@asynccontextmanager
async def lifespan(_: FastAPI):
    for d in (UPLOADS, MEDIA):
        d.mkdir(parents=True, exist_ok=True)
    db.init(DATA / "mimityph.db")
    yield


app = FastAPI(title="Mimi Typh API", version="0.1.0", lifespan=lifespan)
MEDIA.mkdir(parents=True, exist_ok=True)
app.mount("/media", StaticFiles(directory=MEDIA), name="media")


# ---------- auth ----------
def current_user(authorization: str = Header(default="")):
    token = authorization.removeprefix("Bearer ").strip()
    user = db.user_by_token(token) if token else None
    if not user:
        raise HTTPException(401, "Нужна авторизация")
    return user


class GuestIn(BaseModel):
    name: str = Field(min_length=2, max_length=24, pattern=r"^[\w.\-]+$")
    device: str = Field(default="unknown", max_length=64)


@app.post("/api/auth/guest")
def guest(body: GuestIn):
    """Вход по нику (без пароля — прототип). Для продакшена добавить пароль/OAuth."""
    uid, token = db.login_guest(body.name, body.device)
    return {"user_id": uid, "name": body.name, "token": token}


# ---------- serialization ----------
def video_json(r) -> dict:
    return {
        "id": r["id"], "kind": r["kind"], "author": r["author"], "caption": r["caption"],
        "video_url": f"/media/{Path(r['video_path']).name}" if r["video_path"] else None,
        "thumb_url": f"/media/{Path(r['thumb_path']).name}" if r["thumb_path"] else None,
        "tiktok_url": r["tiktok_url"], "tiktok_html": r["tiktok_html"],
        "duration": r["duration"], "likes": r["likes"], "comments": r["comments"],
        "liked": bool(r["liked"]), "created_at": r["created_at"],
    }


# ---------- feed ----------
@app.get("/api/feed")
def get_feed(before: int | None = None, limit: int = 10, user=Depends(current_user)):
    rows = db.feed(user["id"], before, max(1, min(limit, 30)))
    items = [video_json(r) for r in rows]
    return {"items": items, "next_before": items[-1]["id"] if len(items) == limit else None}


# ---------- upload ----------
async def _process_job(video_id: int, owner_id: int, src: Path) -> None:
    """Process media off-loop, but keep WebSocket sends on the app's event loop."""
    try:
        video, thumb, dur = await asyncio.to_thread(media.process, src, MEDIA, f"v{video_id}")
        db.finish_video(video_id, True, str(video), str(thumb), dur)
        ok = True
    except Exception:
        db.finish_video(video_id, False)
        ok = False
    finally:
        src.unlink(missing_ok=True)
    await hub.to_user(owner_id, {"type": "video_status", "video_id": video_id,
                                 "status": "ready" if ok else "failed"})
    if ok:
        await hub.to_all({"type": "new_video", "video_id": video_id})


@app.post("/api/videos", status_code=202)
async def upload(tasks: BackgroundTasks, file: UploadFile = File(...),
                 caption: str = Form("", max_length=300), user=Depends(current_user)):
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED_EXT:
        raise HTTPException(415, f"Формат не поддерживается: {ext or 'неизвестен'}")
    src = UPLOADS / f"{uuid.uuid4().hex}{ext}"
    size = 0
    with src.open("wb") as out:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_UPLOAD:
                out.close(); src.unlink(missing_ok=True)
                raise HTTPException(413, "Файл больше 300 МБ")
            out.write(chunk)
    vid = db.add_video(user["id"], "file", caption)
    tasks.add_task(_process_job, vid, user["id"], src)
    return {"video_id": vid, "status": "processing"}


class TikTokIn(BaseModel):
    url: str = Field(max_length=500)
    caption: str = Field(default="", max_length=300)


@app.post("/api/videos/tiktok", status_code=201)
async def add_tiktok(body: TikTokIn, user=Depends(current_user)):
    try:
        info = await tiktok.fetch(body.url)
    except tiktok.BadTikTokUrl as e:
        raise HTTPException(422, str(e))
    vid = db.add_video(user["id"], "tiktok", body.caption or info["title"],
                       tiktok_url=info["url"], tiktok_html=info["html"])
    await hub.to_all({"type": "new_video", "video_id": vid})
    return {"video_id": vid}


# ---------- likes / comments ----------
def _must_exist(video_id: int, uid: int):
    row = db.get_video(uid, video_id)
    if not row:
        raise HTTPException(404, "Видео не найдено")
    return row


@app.post("/api/videos/{video_id}/like")
async def like(video_id: int, user=Depends(current_user)):
    _must_exist(video_id, user["id"])
    liked = db.toggle_like(user["id"], video_id)
    row = db.get_video(user["id"], video_id)
    await hub.to_user(user["id"], {"type": "like", "video_id": video_id, "liked": liked,
                                   "likes": row["likes"]})
    return {"liked": liked, "likes": row["likes"]}


class CommentIn(BaseModel):
    text: str = Field(min_length=1, max_length=500)


@app.get("/api/videos/{video_id}/comments")
def comments(video_id: int, user=Depends(current_user)):
    _must_exist(video_id, user["id"])
    return [dict(r) for r in db.list_comments(video_id)]


@app.post("/api/videos/{video_id}/comments", status_code=201)
async def post_comment(video_id: int, body: CommentIn, user=Depends(current_user)):
    _must_exist(video_id, user["id"])
    cid = db.add_comment(user["id"], video_id, body.text.strip())
    await hub.to_all({"type": "comment", "video_id": video_id, "comment_id": cid})
    return {"comment_id": cid}


# ---------- sync between devices ----------
@app.websocket("/ws")
async def ws(socket: WebSocket, token: str = ""):
    user = db.user_by_token(token)
    if not user:
        await socket.close(code=4401)
        return
    await socket.accept()
    hub.add(user["id"], socket)
    try:
        while True:
            msg = await socket.receive_json()
            # клиент шлёт состояние (например позицию просмотра) -> остальным устройствам аккаунта
            if msg.get("type") == "sync":
                await hub.to_user(user["id"], {"type": "sync", "data": msg.get("data")})
    except WebSocketDisconnect:
        pass
    finally:
        hub.remove(user["id"], socket)


@app.get("/api/health")
def health():
    return {"ok": True}

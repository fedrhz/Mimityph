import asyncio
import shutil
import subprocess
import threading
from pathlib import Path

import pytest

from app import db, media, tiktok


@pytest.fixture()
def fresh(tmp_path):
    db.init(tmp_path / "t.db")
    return tmp_path


def test_login_two_devices_same_user(fresh):
    u1, t1 = db.login_guest("mimi", "phone")
    u2, t2 = db.login_guest("mimi", "pc")
    assert u1 == u2 and t1 != t2
    assert db.user_by_token(t2)["name"] == "mimi"
    assert db.user_by_token("bad") is None


def test_feed_like_comment(fresh):
    uid, _ = db.login_guest("mimi", "d")
    other, _ = db.login_guest("fan", "d")
    vid = db.add_video(uid, "tiktok", "hi", tiktok_url="https://www.tiktok.com/@a/video/1",
                       tiktok_html="<blockquote></blockquote>")
    assert db.toggle_like(other, vid) is True
    assert db.toggle_like(other, vid) is False
    db.toggle_like(other, vid)
    db.add_comment(other, vid, "мило")
    row = db.feed(other, None, 10)[0]
    assert (row["likes"], row["comments"], bool(row["liked"])) == (1, 1, True)
    assert db.feed(uid, None, 10)[0]["liked"] == 0


def test_processing_videos_hidden_until_ready(fresh):
    uid, _ = db.login_guest("mimi", "d")
    vid = db.add_video(uid, "file", "x")
    assert db.feed(uid, None, 10) == []
    db.finish_video(vid, True, "a.mp4", "a.jpg", 3.0)
    assert len(db.feed(uid, None, 10)) == 1


def test_feed_pagination(fresh):
    uid, _ = db.login_guest("mimi", "d")
    ids = [db.add_video(uid, "tiktok", str(i), tiktok_url="u", tiktok_html="h") for i in range(5)]
    page = db.feed(uid, None, 2)
    assert [r["id"] for r in page] == ids[::-1][:2]
    assert [r["id"] for r in db.feed(uid, page[-1]["id"], 2)] == ids[::-1][2:4]


@pytest.mark.parametrize("url,ok", [
    ("https://www.tiktok.com/@a/video/1", True), ("https://vm.tiktok.com/abc/", True),
    ("http://www.tiktok.com/@a/video/1", False), ("https://evil.com/tiktok.com", False),
    ("https://tiktok.com.evil.com/x", False), ("javascript:alert(1)", False)])
def test_tiktok_validate(url, ok):
    if ok:
        assert tiktok.validate(url)
    else:
        with pytest.raises(tiktok.BadTikTokUrl):
            tiktok.validate(url)


def test_tiktok_sanitize():
    assert "<script" not in tiktok.sanitize_html(
        '<blockquote>x</blockquote><script async src="https://www.tiktok.com/embed.js"></script>')
    with pytest.raises(tiktok.BadTikTokUrl):
        tiktok.sanitize_html("<script>alert(1)</script>")


@pytest.mark.skipif(not shutil.which("ffmpeg"), reason="ffmpeg не установлен")
def test_ffmpeg_pipeline(tmp_path):
    src = tmp_path / "in.mp4"
    subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i", "testsrc=size=640x360:rate=25",
                    "-f", "lavfi", "-i", "sine=frequency=440", "-t", "2",
                    "-pix_fmt", "yuv420p", str(src)], check=True, capture_output=True)
    video, thumb, dur = media.process(src, tmp_path / "out", "v1")
    assert video.exists() and thumb.exists() and 1.5 < dur < 2.5



def test_processing_job_keeps_websocket_sends_on_event_loop(tmp_path, monkeypatch):
    from app import main

    src = tmp_path / "source.mp4"
    src.write_bytes(b"test")
    main.MEDIA = tmp_path / "media"
    main.MEDIA.mkdir()

    caller_thread = threading.get_ident()
    process_threads = []
    sent = []

    def fake_process(*args):
        process_threads.append(threading.get_ident())
        video = tmp_path / "video.mp4"
        thumb = tmp_path / "thumb.jpg"
        video.write_bytes(b"video")
        thumb.write_bytes(b"thumb")
        return video, thumb, 2.0

    def fake_finish(*args):
        pass

    async def fake_to_user(user_id, event):
        sent.append(("user", threading.get_ident(), event["type"]))

    async def fake_to_all(event):
        sent.append(("all", threading.get_ident(), event["type"]))

    monkeypatch.setattr(main.media, "process", fake_process)
    monkeypatch.setattr(main.db, "finish_video", fake_finish)
    monkeypatch.setattr(main.hub, "to_user", fake_to_user)
    monkeypatch.setattr(main.hub, "to_all", fake_to_all)

    asyncio.run(main._process_job(1, 2, src))

    assert process_threads and process_threads[0] != caller_thread
    assert [item[0] for item in sent] == ["user", "all"]
    assert all(item[1] == caller_thread for item in sent)
    assert not src.exists()

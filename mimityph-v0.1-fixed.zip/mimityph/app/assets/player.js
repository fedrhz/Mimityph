// Автоплей видео в зоне видимости + подгрузка встроенного плеера TikTok.
(function () {
  if (window.__mimiPlayer) return;
  window.__mimiPlayer = true;
  const io = new IntersectionObserver((entries) => {
    for (const e of entries) {
      const v = e.target.querySelector('video');
      if (!v) continue;
      if (e.isIntersecting && e.intersectionRatio > 0.6) v.play().catch(() => {});
      else v.pause();
    }
  }, { threshold: [0.6] });
  const scan = () => {
    document.querySelectorAll('.card').forEach((c) => io.observe(c));
    document.querySelectorAll('video').forEach((v) => {
      if (v.dataset.bound) return;
      v.dataset.bound = '1';
      v.addEventListener('click', () => {
        if (v.muted) { v.muted = false; return; }   // первый тап включает звук
        v.paused ? v.play() : v.pause();
      });
      v.addEventListener('timeupdate', () => {
        const bar = v.parentElement.querySelector('.progress > i');
        if (bar && v.duration) bar.style.width = (100 * v.currentTime / v.duration) + '%';
      });
    });
    if (document.querySelector('.tiktok-embed') && !document.getElementById('tt-embed')) {
      const s = document.createElement('script');
      s.id = 'tt-embed'; s.async = true; s.src = 'https://www.tiktok.com/embed.js';
      document.body.appendChild(s);
    }
  };
  new MutationObserver(scan).observe(document.body, { childList: true, subtree: true });
  scan();
})();

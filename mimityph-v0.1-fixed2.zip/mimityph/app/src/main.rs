use dioxus::prelude::*;
use mimityph_core::{api::Api, format::count_ru, types::Video};

const CSS: &str = include_str!("../assets/style.css");
const JS: &str = include_str!("../assets/player.js");
/// Адрес сервера задаётся при сборке: MIMITYPH_SERVER=http://192.168.0.10:8000
/// По умолчанию — хост-машина из Android-эмулятора.
const SERVER: &str = match option_env!("MIMITYPH_SERVER") {
    Some(s) => s,
    None => "http://10.0.2.2:8000",
};

fn main() {
    dioxus::launch(App);
}

#[derive(Clone, Copy, PartialEq)]
enum Sheet {
    None,
    Upload,
    Comments(i64),
}

#[component]
fn App() -> Element {
    let mut session = use_signal(|| None::<Api>);
    let body = match session() {
        None => rsx! { Login { on_login: move |api| session.set(Some(api)) } },
        Some(api) => rsx! { Home { api } },
    };
    rsx! {
        style { "{CSS}" }
        {body}
    }
}

// ---------- вход ----------
#[component]
fn Login(on_login: Callback<Api>) -> Element {
    let mut name = use_signal(String::new);
    let mut err = use_signal(String::new);
    let mut busy = use_signal(|| false);

    let submit = move |_| {
        let n = name().trim().to_string();
        spawn(async move {
            busy.set(true);
            err.set(String::new());
            let api = Api::new(SERVER);
            match api.login(&n, std::env::consts::OS).await {
                Ok(s) => on_login.call(api.with_token(s.token)),
                Err(e) => err.set(e.to_string()),
            }
            busy.set(false);
        });
    };

    rsx! {
        main { class: "login",
            h1 { "Mimi Typh 🐾" }
            p { class: "note", "Введите ник. С тем же ником на другом устройстве вы увидите свои лайки и загрузки." }
            input { placeholder: "Ник (буквы, цифры, _ . -)", value: "{name}", oninput: move |e| name.set(e.value()) }
            if !err().is_empty() { p { class: "err", "{err}" } }
            button { class: "primary", disabled: busy() || name().trim().len() < 2, onclick: submit,
                if busy() { "Входим…" } else { "Войти" }
            }
        }
    }
}

// ---------- главный экран ----------
#[component]
fn Home(api: Api) -> Element {
    let mut videos = use_signal(Vec::<Video>::new);
    let mut error = use_signal(String::new);
    let mut sheet = use_signal(|| Sheet::None);
    let mut tab = use_signal(|| 0usize);

    let load_api = api.clone();
    let reload = use_callback(move |_: ()| {
        let api = load_api.clone();
        spawn(async move {
            match api.feed(None).await {
                Ok(p) => { error.set(String::new()); videos.set(p.items) }
                Err(e) => error.set(e.to_string()),
            }
        });
    });
    use_effect(move || reload.call(()));
    use_effect(move || { document::eval(JS); });

    let like_api = api.clone();
    let on_like = use_callback(move |id: i64| {
        let api = like_api.clone();
        spawn(async move {
            match api.like(id).await {
                Ok(r) => {
                    if let Some(v) = videos.write().iter_mut().find(|v| v.id == id) {
                        v.liked = r.liked;
                        v.likes = r.likes;
                    }
                }
                Err(e) => error.set(e.to_string()),
            }
        });
    });
    let on_comments = use_callback(move |id: i64| sheet.set(Sheet::Comments(id)));

    let sheet_view = match sheet() {
        Sheet::None => rsx! {},
        Sheet::Upload => rsx! {
            UploadSheet { api: api.clone(), on_close: move |_| sheet.set(Sheet::None), on_done: move |_| { sheet.set(Sheet::None); reload.call(()) } }
        },
        Sheet::Comments(id) => rsx! {
            CommentsSheet { api: api.clone(), video_id: id, on_close: move |_| sheet.set(Sheet::None) }
        },
    };

    rsx! {
        header { class: "top",
            span { class: "logo", "Mimi Typh 🐾" }
            nav { class: "tabs",
                button { class: if tab() == 0 { "on" }, onclick: move |_| tab.set(0), "Для тебя" }
                button { class: if tab() == 1 { "on" }, onclick: move |_| tab.set(1), "Подписки" }
            }
        }
        if !error().is_empty() { p { class: "err", style: "position:fixed;top:72px;left:16px;right:16px;z-index:9", "{error}" } }
        main { class: "feed",
            if videos().is_empty() && error().is_empty() {
                section { class: "card embed", p { class: "note", "Пока пусто. Нажмите лапу внизу и загрузите первое видео." } }
            }
            for v in videos() {
                Card { key: "{v.id}", video: v.clone(), api: api.clone(), on_like, on_comments }
            }
        }
        footer { class: "nav",
            button { class: "on", aria_label: "Главная", {icon_home()} "Главная" }
            button { aria_label: "Интересное", {icon_compass()} "Интересное" }
            button { class: "upload", aria_label: "Загрузить видео", onclick: move |_| sheet.set(Sheet::Upload),
                {icon_paw()} span { "+" }
            }
            button { aria_label: "Входящие", {icon_inbox()} "Входящие" }
            button { aria_label: "Профиль", {icon_user()} "Профиль" }
        }
        {sheet_view}
    }
}

// ---------- карточка видео ----------
#[component]
fn Card(video: Video, api: Api, on_like: Callback<i64>, on_comments: Callback<i64>) -> Element {
    let id = video.id;
    let words: Vec<&str> = video.caption.split_whitespace().collect();
    let text = words.iter().filter(|w| !w.starts_with('#')).cloned().collect::<Vec<_>>().join(" ");
    let tags = words.iter().filter(|w| w.starts_with('#')).cloned().collect::<Vec<_>>().join(" ");
    let initial = video.author.chars().next().unwrap_or('?').to_uppercase().to_string();
    let poster = video.thumb_url.as_ref().map(|t| api.abs_url(t));
    let src = video.video_url.as_ref().map(|u| api.abs_url(u));

    rsx! {
        section { class: "card",
            if let Some(html) = video.tiktok_html.clone() {
                div { class: "embed", dangerous_inner_html: "{html}" }
            } else if let Some(src) = src {
                video { src: "{src}", poster: poster, r#loop: true, muted: true, preload: "metadata", "playsinline": "true" }
                div { class: "progress", i {} }
            }
            div { class: "shade" }
            div { class: "rail",
                button { class: if video.liked { "liked" }, aria_label: "Нравится", onclick: move |_| on_like.call(id),
                    {icon_heart()} "{count_ru(video.likes)}" }
                button { aria_label: "Комментарии", onclick: move |_| on_comments.call(id),
                    {icon_comment()} "{count_ru(video.comments)}" }
                button { aria_label: "Сохранить", {icon_bookmark()} "Сохр." }
                button { aria_label: "Поделиться", {icon_share()} "Поделиться" }
            }
            div { class: "disc", aria_label: "Звук", "♫" }
            div { class: "meta",
                div { class: "author",
                    span { class: "avatar", "{initial}" }
                    b { "{video.author} 🐾" }
                    button { class: "follow", "Подписаться" }
                    button { class: "more", aria_label: "Ещё", "⋯" }
                }
                if !text.is_empty() { p { class: "cap", "{text}" } }
                if !tags.is_empty() { p { class: "tags", "{tags}" } }
                p { class: "track", "♫ Оригинальный звук — {video.author}" }
            }
        }
    }
}

// ---------- загрузка ----------
#[component]
fn UploadSheet(api: Api, on_close: Callback<()>, on_done: Callback<()>) -> Element {
    let mut caption = use_signal(String::new);
    let mut link = use_signal(String::new);
    let mut msg = use_signal(String::new);
    let mut busy = use_signal(|| false);

    let file_api = api.clone();
    let tiktok_api = api.clone();

    rsx! {
        div { class: "sheet", onclick: move |_| on_close.call(()),
            div { onclick: move |e| e.stop_propagation(),
                h2 { "Новое видео" }
                textarea { rows: "2", placeholder: "Подпись и #хэштеги", value: "{caption}", oninput: move |e| caption.set(e.value()) }
                label { class: "primary", style: "text-align:center",
                    "Выбрать файл с устройства"
                    input { r#type: "file", accept: "video/*", style: "display:none",
                        onchange: move |evt| {
                            let api = file_api.clone();
                            async move {
                                let Some(engine) = evt.files() else { return };
                                let Some(name) = engine.files().first().cloned() else { return };
                                busy.set(true);
                                msg.set("Загружаем…".into());
                                match engine.read_file(&name).await {
                                    Some(bytes) => match api.upload_bytes(name, bytes, &caption()).await {
                                        Ok(()) => { msg.set(String::new()); on_done.call(()) }
                                        Err(e) => msg.set(e.to_string()),
                                    },
                                    None => msg.set("Не удалось прочитать файл".into()),
                                }
                                busy.set(false);
                            }
                        }
                    }
                }
                p { class: "note", "Видео появится в ленте после обработки на сервере (до минуты)." }
                h2 { "Или ссылка TikTok" }
                p { class: "note", "Покажем встроенный плеер TikTok. Видео не скачивается и не перезаливается." }
                input { placeholder: "https://www.tiktok.com/@…/video/…", value: "{link}", oninput: move |e| link.set(e.value()) }
                button { class: "primary", disabled: busy() || link().trim().is_empty(),
                    onclick: move |_| {
                        let api = tiktok_api.clone();
                        spawn(async move {
                            busy.set(true);
                            match api.add_tiktok(link().trim(), &caption()).await {
                                Ok(()) => on_done.call(()),
                                Err(e) => msg.set(e.to_string()),
                            }
                            busy.set(false);
                        });
                    },
                    "Добавить ссылку"
                }
                if !msg().is_empty() { p { class: "err", "{msg}" } }
            }
        }
    }
}

// ---------- комментарии ----------
#[component]
fn CommentsSheet(api: Api, video_id: i64, on_close: Callback<()>) -> Element {
    let mut text = use_signal(String::new);
    let list_api = api.clone();
    let mut list = use_resource(move || {
        let api = list_api.clone();
        async move { api.comments(video_id).await }
    });

    rsx! {
        div { class: "sheet", onclick: move |_| on_close.call(()),
            div { onclick: move |e| e.stop_propagation(),
                h2 { "Комментарии" }
                match &*list.read() {
                    None => rsx! { p { class: "note", "Загружаем…" } },
                    Some(Err(e)) => rsx! { p { class: "err", "{e}" } },
                    Some(Ok(items)) if items.is_empty() => rsx! { p { class: "note", "Пока нет комментариев. Напишите первый." } },
                    Some(Ok(items)) => rsx! {
                        for c in items.iter() { p { class: "cmt", key: "{c.id}", b { "{c.author}" } "{c.text}" } }
                    },
                }
                input { placeholder: "Ваш комментарий", value: "{text}", oninput: move |e| text.set(e.value()) }
                button { class: "primary", disabled: text().trim().is_empty(),
                    onclick: move |_| {
                        let api = api.clone();
                        spawn(async move {
                            if api.add_comment(video_id, text().trim()).await.is_ok() {
                                text.set(String::new());
                                list.restart();
                            }
                        });
                    },
                    "Отправить"
                }
            }
        }
    }
}

// ---------- иконки ----------
fn icon_heart() -> Element { rsx! { svg { view_box: "0 0 24 24", path { d: "M12 21s-8-5-9.5-10A5 5 0 0 1 12 6a5 5 0 0 1 9.5 5C20 16 12 21 12 21z" } } } }
fn icon_comment() -> Element { rsx! { svg { view_box: "0 0 24 24", path { d: "M4 5h16v11H9l-5 4z" } } } }
fn icon_bookmark() -> Element { rsx! { svg { view_box: "0 0 24 24", path { d: "M6 3h12v18l-6-4-6 4z" } } } }
fn icon_share() -> Element { rsx! { svg { view_box: "0 0 24 24", path { d: "M14 4l7 7-7 7v-4c-6 0-9 2-11 5 1-6 4-10 11-10z" } } } }
fn icon_home() -> Element { rsx! { svg { view_box: "0 0 24 24", path { d: "M3 11l9-8 9 8v10h-6v-6H9v6H3z" } } } }
fn icon_compass() -> Element { rsx! { svg { view_box: "0 0 24 24", circle { cx: "12", cy: "12", r: "9" } path { d: "M15 9l-2 6-4 0 2-6z" } } } }
fn icon_inbox() -> Element { rsx! { svg { view_box: "0 0 24 24", path { d: "M4 5h16v12H9l-5 4z" } } } }
fn icon_user() -> Element { rsx! { svg { view_box: "0 0 24 24", circle { cx: "12", cy: "8", r: "4" } path { d: "M4 21c0-4 4-7 8-7s8 3 8 7" } } } }
fn icon_paw() -> Element {
    rsx! { svg { view_box: "0 0 24 24", style: "fill:currentColor;stroke:none",
        circle { cx: "6", cy: "10", r: "2.2" } circle { cx: "10", cy: "5.5", r: "2.2" }
        circle { cx: "14", cy: "5.5", r: "2.2" } circle { cx: "18", cy: "10", r: "2.2" }
        path { d: "M12 11c-3 0-6 3-6 6 0 2 2 3 4 2.4 1.4-.4 2.6-.4 4 0 2 .6 4-.4 4-2.4 0-3-3-6-6-6z" } } }
}
